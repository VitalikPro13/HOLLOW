#!/bin/bash
. "$DEPLOY/lib/common.sh"
. "$DEPLOY/lib/release_feed.sh"
. "$DEPLOY/lib/ui.sh"
